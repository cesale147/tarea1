package pweb.data;

import pweb.business.User;

public class UserDB {

    public static long insert(User user) {
        // TODO: Agregar codigo que permita crear un nuevo usuario en la base de datos 
        // NOTE: Esto se mostrara en sesiones posteriores
        return 0;
    }
}
